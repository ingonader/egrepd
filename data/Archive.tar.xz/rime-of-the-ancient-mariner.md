THE RIME OF THE ANCIENT MARINER

IN SEVEN PARTS

By Samuel Taylor Coleridge



PART THE FIRST.

It is an ancient Mariner,
And he stoppeth one of three.
"By thy long grey beard and glittering eye,
Now wherefore stopp'st thou me?

"The Bridegroom's doors are opened wide,
And I am next of kin;
The guests are met, the feast is set:
May'st hear the merry din."

He holds him with his skinny hand,
"There was a ship," quoth he.
"Hold off! unhand me, grey-beard loon!"
Eftsoons his hand dropt he.

He holds him with his glittering eye--
The Wedding-Guest stood still,
And listens like a three years child:
The Mariner hath his will.

The Wedding-Guest sat on a stone:
He cannot chuse but hear;
And thus spake on that ancient man,
The bright-eyed Mariner.

The ship was cheered, the harbour cleared,
Merrily did we drop
Below the kirk, below the hill,
Below the light-house top.

The Sun came up upon the left,
Out of the sea came he!
And he shone bright, and on the right
Went down into the sea.

Higher and higher every day,
Till over the mast at noon--
The Wedding-Guest here beat his breast,
For he heard the loud bassoon.

The bride hath paced into the hall,
Red as a rose is she;
Nodding their heads before her goes
The merry minstrelsy.

The Wedding-Guest he beat his breast,
Yet he cannot chuse but hear;
And thus spake on that ancient man,
The bright-eyed Mariner.

And now the STORM-BLAST came, and he
Was tyrannous and strong:
He struck with his o'ertaking wings,
And chased south along.

With sloping masts and dipping prow,
As who pursued with yell and blow
Still treads the shadow of his foe
And forward bends his head,
The ship drove fast, loud roared the blast,
And southward aye we fled.

And now there came both mist and snow,
And it grew wondrous cold:
And ice, mast-high, came floating by,
As green as emerald.

And through the drifts the snowy clifts
Did send a dismal sheen:
Nor shapes of men nor beasts we ken--
The ice was all between.

The ice was here, the ice was there,
The ice was all around:
It cracked and growled, and roared and howled,
Like noises in a swound!

At length did cross an Albatross:
Thorough the fog it came;
As if it had been a Christian soul,
We hailed it in God's name.

It ate the food it ne'er had eat,
And round and round it flew.
The ice did split with a thunder-fit;
The helmsman steered us through!

And a good south wind sprung up behind;
The Albatross did follow,
And every day, for food or play,
Came to the mariners' hollo!

In mist or cloud, on mast or shroud,
It perched for vespers nine;
Whiles all the night, through fog-smoke white,
Glimmered the white Moon-shine.

"God save thee, ancient Mariner!
From the fiends, that plague thee thus!--
Why look'st thou so?"--With my cross-bow
I shot the ALBATROSS.
